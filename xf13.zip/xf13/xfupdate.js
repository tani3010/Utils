//X-Finder �����X�V�c�[�� 1.05(WMI/xf64�Ή���) Gaku
//MIT License

fso = new ActiveXObject("Scripting.FileSystemObject");
wsh = new ActiveXObject("WScript.Shell");
sha = new ActiveXObject("Shell.Application");

MB_ICONQUESTION      = 0x0020;
MB_ICONINFORMATION   = 0x0040;
MB_OKCANCEL          = 0x0001;
IDOK = 1;

adTypeBinary = 1;
adSaveCreateOverWrite = 2;

FOF_NOCONFIRMATION        = 0x0010;

createHttpRequest = function ()
{
	try {
		return new ActiveXObject("Msxml2.XMLHTTP");
	} catch(e) {
		return new ActiveXObject("Microsoft.XMLHTTP");
	}
	return null;
}

function alert(s)
{
	wsh.Popup(s, 0, "X-Finder", MB_ICONINFORMATION);
}

function CalcVersion(s)
{
	if (s.match(/(\d+)\-(\d+)\-(\d+)/)) {
		return RegExp.$1 * 100000000 + RegExp.$2 * 10000 + RegExp.$3 * 1;
	}
	if (s.match(/(\d+)\-(\d+)/)) {
		return RegExp.$1 * 100000000 + RegExp.$2 * 10000;
	}
	if (s.match(/(\d+)/)) {
		return RegExp.$1 * 100000000;
	}
	return 0;
}

//�C���X�g�[�����Ă���X-Finder�̃o�[�W�����𓾂�
folder = fso.GetParentFolderName(WScript.ScriptFullName);
path = fso.BuildPath(folder, "XF.exe");
var xf64 = false;
try {
	ver = fso.GetFileVersion(path).replace(/\.0$/, "").replace(/\.0$/, "").replace(/\./g, "-");
}
catch (e) {
	ver = "0-0";
}

//�T�C�g�̍ŐV�o�[�W�����𓾂�
var url = "http://www.eonet.ne.jp/~gakana/";
var xhr = createHttpRequest();
xhr.open("GET", url + "index.html?" + Math.floor(new Date().getTime() / 60000), false);
xhr.setRequestHeader('Pragma', 'no-cache');
xhr.setRequestHeader('Cache-Control', 'no-cache');
xhr.setRequestHeader('If-Modified-Since', 'Thu, 01 Jun 1970 00:00:00 GMT');
xhr.send(null);
var html = xhr.responseText;
var develop = "";
var official = "";
if (html.match(/download\/xf(\d+\-?\d*)\.html/i)) {
	official = RegExp.$1;
}
var site, dl;
var res = 0;
if (Math.floor(CalcVersion(official) / 10000) - Math.floor(CalcVersion(ver) / 10000) == 0) {
	res = wsh.Popup("�J���r��ł��`�F�b�N�̑Ώۂɂ��܂����H", 0, "X-Finder" , MB_ICONQUESTION | MB_OKCANCEL);
	if (res < 0) {
		WScript.Quit();
	}
}
if	(res == IDOK) {
	if (html.match(/develop\/xf(\d+\-\d+\-\d+)\.html/i)) {
		develop = RegExp.$1;
	}
}

//�����ŁE�J���r���
if (CalcVersion(develop) > CalcVersion(official)) {
	site = develop;
	dl = "develop/";
}
else {
	site = official;
	dl = "download/";
}

//�ŐV�`�F�b�N
if (CalcVersion(site) <= CalcVersion(ver)) {
	alert("X-Finder " + ver + "\n�ŐV�o�[�W�����ł��B");
	WScript.Quit();
}

//�m�F
if	(wsh.Popup("�V�����o�[�W����������܂��B\nX-Finder " + site + "\n�C���X�g�[�����܂����H", 0, "X-Finder" , MB_ICONQUESTION | MB_OKCANCEL) != IDOK) {
	WScript.Quit();
}

//X-Finder���I��������
var oWMI = GetObject("winmgmts:{impersonationLevel=impersonate}");
if (oWMI) {
	var cols = oWMI.ExecQuery("SELECT * FROM Win32_Process WHERE ExecutablePath = '" + path.replace(/\\/g, "\\\\") + "'");
	for(var list = new Enumerator(cols); !list.atEnd(); list.moveNext()) {
		list.item().terminate();
	}
	//XF64.exe
	cols = oWMI.ExecQuery("SELECT * FROM Win32_Process WHERE ExecutablePath = '" + path.replace(/\\/g, "\\\\").replace(/XF\.exe$/, "XF64.exe") + "'");
	for(var list = new Enumerator(cols); !list.atEnd(); list.moveNext()) {
		list.item().terminate();
		xf64 = true;
	}
}

//�_�E�����[�h
var temp = fso.BuildPath(wsh.ExpandEnvironmentStrings("%TEMP%"), "tablacus");
if (!fso.FolderExists(temp)) {
	fso.CreateFolder(temp);
}
var file = 'xf' + site + '.cab';
var cabfile = temp + '\\' + file;

xhr.open("GET", url + dl + "dl/" + file, false);
xhr.send(null);
var ado = new ActiveXObject("Adodb.Stream");
ado.Type = adTypeBinary;
ado.Open();
ado["Write"](xhr["r_e_s_p_o_n_s_e_B_o_d_y".replace(/_/g, "")]);
ado.SavetoFile(cabfile, adSaveCreateOverWrite);
ado.Close();

//��
var tempxf = temp + "\\xf";
if (fso.FolderExists(tempxf)) {
	fso.DeleteFolder(tempxf, true);
}
fso.CreateFolder(tempxf);

//expand.exe�ŉ�(WMI��)
var service = GetObject("winmgmts:\\\\.\\root\\cimv2:Win32_Process");
var method = service.Methods_.Item("Create");
var iParams = method.InParameters.SpawnInstance_();
iParams.CommandLine = fso.BuildPath(sha.NameSpace(0x25).Self.Path, 'expand.exe') + ' -r "' + cabfile + '" "' + tempxf + '" -F:*';
var result = service.ExecMethod_(method.Name, iParams);
service = GetObject("winmgmts:\\\\.\\root\\cimv2");
cMonitored = service.ExecNotificationQuery("SELECT * FROM __InstanceDeletionEvent within 1 where TargetInstance isa 'Win32_Process'"); 
do {
    WScript.Sleep(100);
    LatestProcess = cMonitored.NextEvent();
} while (LatestProcess.TargetInstance.ProcessID != result.ProcessId);

//�m�F
if (!fso.FileExists(tempxf +"\\XF.exe")) {
	alert("X-Finder�̓W�J�Ɏ��s���܂����B");
	WScript.Quit();
}

//�C���X�g�[��
sha.NameSpace(folder).MoveHere(sha.NameSpace(tempxf).Items(), FOF_NOCONFIRMATION);

//�X�V���e���m�F
if	(wsh.Popup("�C���X�g�[�����������܂����B\n�X�V���e���m�F���܂����H", 0, "X-Finder" , MB_ICONQUESTION | MB_OKCANCEL) == IDOK) {
	wsh.run(url + dl + 'xf' + site + '.html');
}

//�N��
if	(wsh.Popup("X-Finder���N�����܂����H", 0, "X-Finder" , MB_ICONQUESTION | MB_OKCANCEL) == IDOK) {
	if (xf64) {
		path = path.replace(/XF\.exe$/, "XF64.exe");
	}
	var oExec = wsh.Exec('"' + path + '"');
	wsh.AppActivate(oExec.ProcessID);
}
